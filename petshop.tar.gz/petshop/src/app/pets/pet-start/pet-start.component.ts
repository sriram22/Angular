import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pet-start',
  templateUrl: './pet-start.component.html',
  styleUrls: ['./pet-start.component.css']
})
export class PetStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
